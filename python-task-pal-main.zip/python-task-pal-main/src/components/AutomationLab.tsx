import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

type LogLine = { kind: "info" | "ok" | "err"; text: string };

function CodeBlock({ code }: { code: string }) {
  return (
    <pre className="mt-3 overflow-auto rounded-md border border-border bg-background/60 p-3 font-mono text-[11px] leading-relaxed text-muted-foreground">
      <code>{code}</code>
    </pre>
  );
}

function Console({ lines }: { lines: LogLine[] }) {
  if (!lines.length) return null;
  return (
    <div className="mt-4 rounded-md border border-border bg-background/80 p-3 font-mono text-xs">
      {lines.map((l, i) => (
        <div
          key={i}
          className={
            l.kind === "ok"
              ? "text-[color:var(--lime)]"
              : l.kind === "err"
                ? "text-destructive"
                : "text-muted-foreground"
          }
        >
          <span className="text-muted-foreground/60">$ </span>
          {l.text}
        </div>
      ))}
    </div>
  );
}

function Section({
  num,
  title,
  subtitle,
  pythonCode,
  children,
}: {
  num: string;
  title: string;
  subtitle: string;
  pythonCode: string;
  children: React.ReactNode;
}) {
  const [showCode, setShowCode] = useState(false);
  return (
    <section className="rounded-2xl border border-border bg-card p-6 md:p-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="font-mono text-xs uppercase tracking-widest text-[color:var(--lime)]">
            task_{num}
          </div>
          <h2 className="mt-1 font-display text-2xl font-bold tracking-tight md:text-3xl">
            {title}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
        </div>
        <button
          onClick={() => setShowCode((s) => !s)}
          className="shrink-0 rounded-md border border-border px-3 py-1.5 font-mono text-xs text-muted-foreground hover:border-[color:var(--lime)] hover:text-[color:var(--lime)]"
        >
          {showCode ? "hide .py" : "view .py"}
        </button>
      </div>
      <div className="mt-6">{children}</div>
      {showCode && <CodeBlock code={pythonCode} />}
    </section>
  );
}

// ---------- Task 1: JPG mover ----------
function JpgMover() {
  const [files, setFiles] = useState<File[]>([]);
  const [log, setLog] = useState<LogLine[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  function pick(list: FileList | null) {
    if (!list) return;
    setFiles(Array.from(list));
    setLog([]);
  }

  async function moveJpgs() {
    const jpgs = files.filter((f) => /\.(jpe?g)$/i.test(f.name));
    const others = files.filter((f) => !/\.(jpe?g)$/i.test(f.name));
    const lines: LogLine[] = [
      { kind: "info", text: `scanning ${files.length} file(s) in source/` },
      { kind: "info", text: `found ${jpgs.length} .jpg → moving to jpg_only/` },
    ];
    if (!jpgs.length) {
      setLog([...lines, { kind: "err", text: "no .jpg files to move" }]);
      return;
    }
    // Build a zip-less "move" by downloading each jpg into a virtual folder name
    const { default: JSZip } = await import("jszip");
    const zip = new JSZip();
    const folder = zip.folder("jpg_only")!;
    for (const f of jpgs) {
      folder.file(f.name, await f.arrayBuffer());
      lines.push({ kind: "ok", text: `moved → jpg_only/${f.name}` });
    }
    for (const f of others) {
      lines.push({ kind: "info", text: `skipped ${f.name}` });
    }
    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "jpg_only.zip";
    a.click();
    URL.revokeObjectURL(url);
    lines.push({ kind: "ok", text: `done. downloaded jpg_only.zip` });
    setLog(lines);
  }

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        multiple
        hidden
        onChange={(e) => pick(e.target.files)}
      />
      <div className="flex flex-wrap items-center gap-3">
        <Button
          onClick={() => inputRef.current?.click()}
          variant="outline"
          className="border-border bg-background/50 hover:border-[color:var(--lime)] hover:text-[color:var(--lime)]"
        >
          Select folder of files
        </Button>
        <Button
          onClick={moveJpgs}
          disabled={!files.length}
          className="bg-[color:var(--lime)] text-primary-foreground hover:bg-[color:var(--lime)]/90"
        >
          Move .jpg → jpg_only/
        </Button>
        <span className="font-mono text-xs text-muted-foreground">
          {files.length ? `${files.length} file(s) selected` : "no files"}
        </span>
      </div>
      <Console lines={log} />
    </div>
  );
}

// ---------- Task 2: Email extractor ----------
function EmailExtractor() {
  const [text, setText] = useState("");
  const [emails, setEmails] = useState<string[]>([]);
  const [log, setLog] = useState<LogLine[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  async function loadFile(f: File | null) {
    if (!f) return;
    const t = await f.text();
    setText(t);
    setLog([{ kind: "info", text: `loaded ${f.name} (${t.length} chars)` }]);
  }

  function extract() {
    const re = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
    const found = Array.from(new Set(text.match(re) ?? []));
    setEmails(found);
    setLog((l) => [
      ...l,
      { kind: "info", text: `regex: ${re.source}` },
      {
        kind: found.length ? "ok" : "err",
        text: `extracted ${found.length} unique email(s)`,
      },
    ]);
  }

  function download() {
    const blob = new Blob([emails.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "emails.txt";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        accept=".txt,text/plain"
        hidden
        onChange={(e) => loadFile(e.target.files?.[0] ?? null)}
      />
      <div className="flex flex-wrap items-center gap-3">
        <Button
          onClick={() => inputRef.current?.click()}
          variant="outline"
          className="border-border bg-background/50 hover:border-[color:var(--lime)] hover:text-[color:var(--lime)]"
        >
          Upload .txt
        </Button>
        <Button
          onClick={extract}
          disabled={!text.trim()}
          className="bg-[color:var(--lime)] text-primary-foreground hover:bg-[color:var(--lime)]/90"
        >
          Extract emails
        </Button>
        <Button
          onClick={download}
          disabled={!emails.length}
          variant="outline"
          className="border-border bg-background/50"
        >
          Save emails.txt
        </Button>
      </div>
      <Textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="…or paste text here. Try: contact alice@acme.io or bob_99@mail.co.uk"
        className="mt-4 min-h-32 border-border bg-background/60 font-mono text-xs"
      />
      {emails.length > 0 && (
        <div className="mt-4 rounded-md border border-border bg-background/80 p-3">
          <div className="mb-2 font-mono text-[11px] uppercase tracking-widest text-[color:var(--lime)]">
            output → emails.txt
          </div>
          <ul className="space-y-1 font-mono text-xs">
            {emails.map((e) => (
              <li key={e} className="text-foreground">
                {e}
              </li>
            ))}
          </ul>
        </div>
      )}
      <Console lines={log} />
    </div>
  );
}

// ---------- Task 3: Title scraper ----------
function TitleScraper() {
  const [url, setUrl] = useState("https://example.com");
  const [title, setTitle] = useState("");
  const [log, setLog] = useState<LogLine[]>([]);
  const [loading, setLoading] = useState(false);

  async function scrape() {
    setLoading(true);
    setTitle("");
    const lines: LogLine[] = [{ kind: "info", text: `GET ${url}` }];
    try {
      const proxy = `https://r.jina.ai/${url}`;
      const res = await fetch(proxy);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const body = await res.text();
      // Jina reader returns "Title: ...\n" near the top
      const m =
        body.match(/^Title:\s*(.+)$/m) ??
        body.match(/<title[^>]*>([^<]+)<\/title>/i);
      const t = m ? m[1].trim() : "(no title found)";
      setTitle(t);
      lines.push({ kind: "ok", text: `200 OK — parsed <title>` });
      lines.push({ kind: "ok", text: `title = "${t}"` });
    } catch (err) {
      lines.push({ kind: "err", text: String(err) });
    } finally {
      setLog(lines);
      setLoading(false);
    }
  }

  function save() {
    const blob = new Blob([`${url}\n${title}\n`], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "title.txt";
    a.click();
  }

  return (
    <div>
      <div className="flex flex-wrap items-center gap-3">
        <Input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://example.com"
          className="min-w-64 flex-1 border-border bg-background/60 font-mono text-xs"
        />
        <Button
          onClick={scrape}
          disabled={loading || !url}
          className="bg-[color:var(--lime)] text-primary-foreground hover:bg-[color:var(--lime)]/90"
        >
          {loading ? "Scraping…" : "Scrape title"}
        </Button>
        <Button
          onClick={save}
          disabled={!title}
          variant="outline"
          className="border-border bg-background/50"
        >
          Save title.txt
        </Button>
      </div>
      {title && (
        <div className="mt-4 rounded-md border border-[color:var(--lime)]/30 bg-[color:var(--lime)]/5 p-4">
          <div className="font-mono text-[11px] uppercase tracking-widest text-[color:var(--lime)]">
            page title
          </div>
          <div className="mt-1 font-display text-xl font-semibold">{title}</div>
        </div>
      )}
      <Console lines={log} />
    </div>
  );
}

export default function AutomationLab() {
  return (
    <main className="min-h-screen px-4 py-12 md:px-8 md:py-16">
      <div className="mx-auto max-w-4xl">
        <header className="mb-12">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-[color:var(--lime)] backdrop-blur">
            <span className="size-1.5 rounded-full bg-[color:var(--lime)] animate-pulse" />
            python automation lab
          </div>
          <h1 className="mt-5 font-display text-4xl font-bold tracking-tight md:text-6xl">
            Automate the boring stuff,
            <br />
            <span className="text-[color:var(--lime)]">in your browser.</span>
          </h1>
          <p className="mt-4 max-w-2xl text-muted-foreground">
            Three classic Python micro-scripts — file moving, regex extraction, web
            scraping — running live. Each card shows the equivalent <span className="font-mono text-foreground">.py</span> source.
          </p>
        </header>

        <div className="space-y-6">
          <Section
            num="01"
            title="Move all .jpg files to a new folder"
            subtitle="os + shutil — pick files, get a jpg_only.zip back."
            pythonCode={`import os, shutil

src = "source"
dst = "jpg_only"
os.makedirs(dst, exist_ok=True)

for name in os.listdir(src):
    if name.lower().endswith((".jpg", ".jpeg")):
        shutil.move(os.path.join(src, name),
                    os.path.join(dst, name))
        print(f"moved {name}")`}
          >
            <JpgMover />
          </Section>

          <Section
            num="02"
            title="Extract emails from a .txt file"
            subtitle="re — paste or upload text, get a clean emails.txt."
            pythonCode={`import re

with open("input.txt") as f:
    text = f.read()

pattern = r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
emails = sorted(set(re.findall(pattern, text)))

with open("emails.txt", "w") as f:
    f.write("\\n".join(emails))

print(f"extracted {len(emails)} emails")`}
          >
            <EmailExtractor />
          </Section>

          <Section
            num="03"
            title="Scrape the title of a webpage"
            subtitle="requests + parsing — give a URL, save title.txt."
            pythonCode={`import re, requests

url = "https://example.com"
html = requests.get(url, timeout=10).text
match = re.search(r"<title[^>]*>([^<]+)</title>", html, re.I)
title = match.group(1).strip() if match else "(no title)"

with open("title.txt", "w") as f:
    f.write(f"{url}\\n{title}\\n")

print(title)`}
          >
            <TitleScraper />
          </Section>
        </div>

        <footer className="mt-16 border-t border-border pt-6 font-mono text-xs text-muted-foreground">
          <span className="text-[color:var(--lime)]">$</span> built with python in
          spirit, react in practice.
        </footer>
      </div>
    </main>
  );
}
