import { createFileRoute } from "@tanstack/react-router";
import AutomationLab from "@/components/AutomationLab";

export const Route = createFileRoute("/")({
  component: AutomationLab,
  head: () => ({
    meta: [
      { title: "Python Automation Lab — Move files, extract emails, scrape titles" },
      {
        name: "description",
        content:
          "Three classic Python automations running live in your browser: move .jpg files, extract emails with regex, and scrape webpage titles.",
      },
    ],
  }),
});
